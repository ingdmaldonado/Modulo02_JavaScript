// pantalla1.js

// ✅ Escuchamos el evento load para inicializar cuando el DOM esté completamente cargado
window.addEventListener("load", () => {
  // 🔗 Referencias a los elementos del DOM
  const inputFirstName = document.getElementById("idFirstName");
  const inputLastName = document.getElementById("idLastName");
  const inputEmail = document.getElementById("idEmail");
  const btnAceptar = document.getElementById("idBtnAceptar");

  // 🧠 Recuperamos el estado actual (si ya estaba guardado)
  const estadoActual = JSON.parse(localStorage.getItem("estadoAplicacion")) || {};

  // 🖋️ Volcamos los datos en los campos si existían
  inputFirstName.value = estadoActual.FirstName || "";
  inputLastName.value = estadoActual.LastName || "";
  inputEmail.value = estadoActual.Email || "";

  // 🎧 Actualizamos el estado en memoria a medida que el usuario escribe
  inputFirstName.addEventListener("input", () => {
    estadoActual.FirstName = inputFirstName.value;
    localStorage.setItem("estadoAplicacion", JSON.stringify(estadoActual));
  });

  inputLastName.addEventListener("input", () => {
    estadoActual.LastName = inputLastName.value;
    localStorage.setItem("estadoAplicacion", JSON.stringify(estadoActual));
  });

  inputEmail.addEventListener("input", () => {
    estadoActual.Email = inputEmail.value;
    localStorage.setItem("estadoAplicacion", JSON.stringify(estadoActual));
  });

  // 📤 Botón para enviar los datos y pasar a la siguiente pantalla
  btnAceptar.addEventListener("click", () => {
    // 🔐 Guardamos una última vez antes de cambiar de pantalla
    localStorage.setItem("estadoAplicacion", JSON.stringify(estadoActual));
    // 👉 Redirigimos a pantalla 2
    window.location.href = "pantalla2.html";
  });
});
