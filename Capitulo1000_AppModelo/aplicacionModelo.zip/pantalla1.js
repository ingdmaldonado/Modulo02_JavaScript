// pantalla1.js
// ✅ Lógica de la pantalla1 con estado persistente y control de duplicidad modularizado

import { inicializarInstanciaUnica } from './instanciaUnica.js';
import { guardarEstadoPantalla, leerEstadoPantalla } from './persistenciaEstado.js';

const nombreArchivoActual = window.location.pathname.split("/").pop();
inicializarInstanciaUnica(nombreArchivoActual);

window.addEventListener("load", () => {
  const inputFirstName = document.getElementById("idFirstName");
  const inputLastName = document.getElementById("idLastName");
  const inputEmail = document.getElementById("idEmail");
  const btnAceptar = document.getElementById("idBtnAceptar");

  const estadoActual = leerEstadoPantalla(nombreArchivoActual);

  inputFirstName.value = estadoActual.FirstName || "";
  inputLastName.value = estadoActual.LastName || "";
  inputEmail.value = estadoActual.Email || "";

  inputFirstName.addEventListener("input", () => {
    estadoActual.FirstName = inputFirstName.value;
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
  });

  inputLastName.addEventListener("input", () => {
    estadoActual.LastName = inputLastName.value;
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
  });

  inputEmail.addEventListener("input", () => {
    estadoActual.Email = inputEmail.value;
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
  });

  btnAceptar.addEventListener("click", () => {
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
    window.location.href = "pantalla2.html";
  });
});

window.addEventListener("pageshow", (event) => {
  if (event.persisted) {
    console.log("🕘 Página restaurada desde el historial (bfcache). Usuario volvió con la flecha.");
  } else {
    console.log("✔ Página cargada normalmente (como lo haría el evento load).");
  }
});
