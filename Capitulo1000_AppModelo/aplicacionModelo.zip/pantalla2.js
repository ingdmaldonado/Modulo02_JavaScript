// pantalla2.js

// ✅ Ejecutamos la lógica cuando la página haya terminado de cargar
window.addEventListener("load", () => {
  // 🔗 Referencia al contenedor donde mostraremos el saludo
  const divSaludo = document.getElementById("saludo");
  const btnVolver = document.getElementById("btnVolver");

  // 📥 Cargamos el estado previamente guardado desde localStorage
  const estado = JSON.parse(localStorage.getItem("estadoAplicacion")) || {};

  // 📣 Mostramos un mensaje personalizado con los datos ingresados
  divSaludo.innerHTML = `
    <p>Hola <strong>${estado.FirstName || "[sin nombre]"}</strong> ${estado.LastName || ""},</p>
    <p>hemos registrado tu email: <strong>${estado.Email || "[sin email]"}</strong>.</p>
  `;

  // 🔁 Volver a la pantalla anterior
  btnVolver.addEventListener("click", () => {
    window.location.href = "pantalla1.html";
  });
});
