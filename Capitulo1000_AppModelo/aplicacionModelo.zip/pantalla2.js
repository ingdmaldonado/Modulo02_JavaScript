// pantalla2.js
// ✅ Lógica de la pantalla2 con estado persistente y control de duplicidad modularizado

import { inicializarInstanciaUnica } from './instanciaUnica.js';
import { guardarEstadoPantalla, leerEstadoPantalla } from './persistenciaEstado.js';

const nombreArchivoActual = window.location.pathname.split("/").pop();
inicializarInstanciaUnica(nombreArchivoActual);

window.addEventListener("load", () => {
  const selectPais = document.getElementById("idPais");
  const btnFinalizar = document.getElementById("idBtnFinalizar");

  const estadoActual = leerEstadoPantalla(nombreArchivoActual);
  selectPais.value = estadoActual.pais || "";

  selectPais.addEventListener("change", () => {
    estadoActual.pais = selectPais.value;
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
  });

  btnFinalizar.addEventListener("click", () => {
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
    alert("✅ Estado completo:\n" + localStorage.getItem("estadoAplicacion"));
  });
});

window.addEventListener("pageshow", (event) => {
  if (event.persisted) {
    console.log("🕘 Página restaurada desde el historial (bfcache). Usuario volvió con la flecha.");
  } else {
    console.log("✔ Página cargada normalmente (como lo haría el evento load).");
  }
});
