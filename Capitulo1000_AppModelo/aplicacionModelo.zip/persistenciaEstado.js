// persistenciaEstado.js
const CLAVE_ESTADO = "estadoAplicacion";

function leerTodoElEstado() {
  const raw = localStorage.getItem(CLAVE_ESTADO);
  let estado = [];
  try {
    const data = JSON.parse(raw);
    if (Array.isArray(data)) {
      estado = data;
    }
  } catch (e) {
    console.warn("⚠️ Error al parsear estadoAplicacion:", e);
  }
  return estado;
}

export function leerEstadoPantalla(idPantalla) {
  const estado = leerTodoElEstado();
  const bloque = estado.find(p => p.idPantalla === idPantalla);
  return bloque ? bloque.estado : {};
}

export function guardarEstadoPantalla(idPantalla, nuevoEstado) {
  const estado = leerTodoElEstado().filter(p => p.idPantalla !== idPantalla);
  estado.push({ idPantalla, estado: nuevoEstado });
  localStorage.setItem(CLAVE_ESTADO, JSON.stringify(estado));
}
