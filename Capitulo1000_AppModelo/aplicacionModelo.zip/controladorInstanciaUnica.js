// controladorInstanciaUnica.js

/**
 * Este módulo implementa una lógica universal para evitar que una misma pantalla (HTML) 
 * sea abierta más de una vez en simultáneo en el mismo navegador.
 * 
 * Utiliza localStorage para guardar un identificador único por pantalla.
 * Usa la API `crypto.randomUUID()` para generar un identificador completamente único.
 * Usa el evento `storage` para detectar si otra pestaña activa esa misma pantalla.
 * Además, define un espacio seguro para inicializar el estado de la aplicación dentro de una IIFE.
 */

(() => {
  const nombrePantalla = window.location.pathname.split("/").pop();
  const instanciaId = crypto.randomUUID();
  const claveStorage = `instanciaActiva_${nombrePantalla}`;

  localStorage.setItem(claveStorage, instanciaId);

  window.addEventListener("storage", (e) => {
    if (e.key === claveStorage && e.newValue !== instanciaId) {
      document.body.innerHTML = `
        <div style="text-align:center; padding:2rem;">
          <h1>⚠️ Pantalla Duplicada</h1>
          <p>Otra pestaña está usando esta pantalla actualmente.</p>
        </div>
      `;
      window.stop?.();
    }
  });

  window.addEventListener("beforeunload", () => {
    if (localStorage.getItem(claveStorage) === instanciaId) {
      localStorage.removeItem(claveStorage);
    }
  });

  const estadoAplicacion = {
    FirstName: "",
    LastName: "",
    Email: "",
    Timestamp: Date.now(),
  };

  if (!localStorage.getItem("estadoAplicacion")) {
    localStorage.setItem("estadoAplicacion", JSON.stringify(estadoAplicacion));
  }
})();
