PROYECTO: aplicacionModelo

✅ Dos pantallas con estado persistente
✅ Control de duplicidad por pestaña
✅ Modularización completa
✅ Eventos 'load' y 'pageshow' manejados
✅ Documentación en cada línea

Ideal para mostrar buenas prácticas en clase.
