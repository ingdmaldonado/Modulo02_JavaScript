// instanciaUnica.js
export function inicializarInstanciaUnica(nombrePantalla) {
  const instanciaId = crypto.randomUUID();
  const claveStorage = `instanciaActiva_${nombrePantalla}`;

  localStorage.setItem(claveStorage, instanciaId);

  window.addEventListener("storage", (e) => {
    if (e.key === claveStorage && e.newValue !== instanciaId) {
      document.body.innerHTML = `
        <div style="text-align:center; padding:2rem;">
          <h1>⚠️ Pantalla Duplicada</h1>
          <p>Otra pestaña está usando esta pantalla actualmente.</p>
        </div>
      `;
      window.stop?.();
    }
  });

  window.addEventListener("beforeunload", () => {
    if (localStorage.getItem(claveStorage) === instanciaId) {
      localStorage.removeItem(claveStorage);
    }
  });
}
