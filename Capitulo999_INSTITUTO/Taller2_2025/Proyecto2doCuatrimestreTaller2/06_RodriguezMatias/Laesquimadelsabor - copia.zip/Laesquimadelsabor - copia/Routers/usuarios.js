const express = require("express");
const ServidorWeb= express.Router();
const pool = require("../BD/conexion");

// para enviar datos a la base de datos 
ServidorWeb.post('/enviar',async(req,res)=>{

  const datos=req.body;//guarda en una cosntante los datos 

//-------------------------------------------------------------------//
  try{ 
    //-----------------------------------------------------------//
    //aca vemos si el gmail ya esta reguistrado
  const existe = await pool.query(//el pool.query hace una consulta a la BD
      'SELECT * FROM "Usuario" WHERE usuariogmail=$1',
      [datos.gmail]
    );

    if (existe.rows.length > 0) {
      return res.status(400).json({ mensaje: "Este Gmail ya está registrado" });
    }

    //------------------------------------------------------------//
  const resut= await pool.query(
   'INSERT INTO "Usuario" (usuarionombre,usuariogmail,rol_id,usuariocontraseña)VALUES ($1,$2,$3,$4) RETURNING *',
   [datos.nombre,datos.gmail,5,datos.contraseña.trim()]//inserta los valores a la base de datos 
);
   console.log("Guardado",resut.rows[0]);//muestra el resultado (resut)
 
   res.json({ mensaje: "Registrado", });

}catch(error){//en caso de error va a mostrar esto
      console.error("Error al guardar los datos",error);
      res.status(500).json({error:"error al guardar la base de datos xd",detalle: error.message })
};
});
// para el login
ServidorWeb.post('/login', async (req, res) => {
  const { gmail, contraseña } = req.body;

  try {
    // Buscar usuario con ese Gmail y contraseña
    const result = await pool.query(
      'SELECT * FROM "Usuario" WHERE usuariogmail=$1 AND usuariocontraseña=$2',
      [gmail, contraseña]
    );
    
       if (result.rows.length === 0) {
      // Gmail no existe
      return res.status(404).json({ mensaje: "Usuario no existe o la contraseña es incorrecta" });
    }
    

  const usuario = result.rows[0];
    res.json({
      mensaje: "¡Entraste!",
      usuario: {
        nombre: usuario.usuarionombre,
        gmail: usuario.usuariogmail,
        rol: usuario.rol_id,
        id: usuario.usuarioid,
        rol_nombre: usuario.rol_id === 1 ? "admin" : "usuario"
      }
    });

  } catch (error) {
    console.error("Error en login:", error);
    res.status(500).json({ error: "Error en el login", detalle: error.message });
  }
});
// Obtener todos los usuarios
ServidorWeb.get('/Admin', async (req, res) => {
  try {
    const result = await pool.query(
'SELECT usuarioid, usuarionombre, usuariogmail, usuariocontraseña, rol_id FROM "Usuario" ORDER BY usuarioid');
    res.json(result.rows); // enviamos el arreglo de usuarios

  } catch (error) {
    console.error("Error al obtener usuarios:", error);
    res.status(500).json({ error: "Error al obtener usuarios", detalle: error.message });
  }
});
//podermodificar los datos de la tabla usuario  
ServidorWeb.put('/Admin/:id', async (req, res) => {
  const { id } = req.params;
  const { nombre, gmail, contraseña, rol } = req.body;

  try {
    const result = await pool.query(
        
      `UPDATE "Usuario" 
       SET usuarionombre=$1, usuariogmail=$2, usuariocontraseña=$3, rol_id=$4 
       WHERE usuarioid=$5
       RETURNING *`,
      [nombre, gmail, contraseña, rol, id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ mensaje: "Usuario no encontrado" });
    }

    res.json({ mensaje: "Usuario actualizado", usuario: result.rows[0] });

  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al actualizar usuario", detalle: error.message });
  }
});
//poder eliminar un usuario
ServidorWeb.delete('/Admin/:id', async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query(
      'DELETE FROM "Usuario" WHERE usuarioid=$1 RETURNING *',
      [id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ mensaje: "Usuario no encontrado" });
    }

    res.json({ mensaje: "Usuario eliminado", usuario: result.rows[0] });
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: "Error al eliminar usuario", detalle: error.message });
  }
});
// Obtener todos los roles
ServidorWeb.get('/roles', async (req, res) => {
  try {
    const result = await pool.query('SELECT rol_id, nombre FROM "Roles" ORDER BY rol_id');
    res.json(result.rows);
  } catch (error) {
    console.error("Error al obtener roles:", error);
    res.status(500).json({ error: "Error al obtener roles", detalle: error.message });
  }
});

module.exports = ServidorWeb;