const ClaseExpress=require("express");
const ServidorWeb=ClaseExpress();
const Cors=require('cors');//para que no pueda hacer peticiones de otro domino y no salte error
const path=require("path");//en este caso ayuda a unir rutas para poder comunicarme con mi frontend
const session = require("express-session");



require("dotenv").config()
ServidorWeb.use((req, res, next) => {req.usuario = { nombre: "Matías", rol_id: 1 }; 
  next();
});
ServidorWeb.use(session({secret: process.env.SESSION_SECRET,resave: false,saveUninitialized: false,}));
ServidorWeb.use(Cors());
ServidorWeb.use(ClaseExpress.static(path.join(__dirname,'Frontend')));
ServidorWeb.use('/Registro',ClaseExpress.static(path.join(__dirname,'Frontend','Registro')));// lacaperte frontend como archivos staticos
ServidorWeb.use('/Login', ClaseExpress.static(path.join(__dirname, 'Frontend', 'Login')));
ServidorWeb.use('/Admin',ClaseExpress.static(path.join(__dirname,'Frontend','Admin')));

ServidorWeb.use(ClaseExpress.urlencoded({ extended: true }));//lee los formularios de frontend
ServidorWeb.use(ClaseExpress.json());//para que pueda leer json




const usuariosRoutes = require("./Routers/usuarios");
ServidorWeb.use(usuariosRoutes);

const Port=3000//establece un puerto
//ultimas lineas de codigo
ServidorWeb.listen(Port,()=>{
  console.log("andando");
})
