const formLogin = document.getElementById('formularioLogin');
const resultadoLogin = document.getElementById('resultadoLogin');
const btnIrInicio = document.getElementById('btnIrInicio');

  if (btnIrInicio) {
    btnIrInicio.addEventListener('click', () => {
      window.location.href = '../inicio.html'; // redirige a inicio.html
    });
  }
formLogin.addEventListener('submit', async (e) => {
  e.preventDefault(); // Evita que la página se recargue

  // Obtenemos los valores ingresados
  const gmail = document.getElementById('loginGmail').value;
  const contraseña = document.getElementById('loginContraseña').value;

  try {
    // Enviamos los datos al backend usando fetch
    const response = await fetch('http://localhost:3000/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ gmail, contraseña })
    });

    const data = await response.json();

    if (data.usuario) {
      // Guardamos los datos del usuario en localStorage
      localStorage.setItem("usuario", JSON.stringify(data.usuario));
      // Redirigimos a la página de inicio
     if (data.usuario.rol == 1) {
    window.location.href = "/Admin/admin.html";
  } else {
    window.location.href = "/inicio.html";
  }
    } else {
      alert(data.mensaje || "Error en el login");
    }

  } catch (error) {
    console.error("Error en el login:", error);
    alert("Ocurrió un error al iniciar sesión");
  }
});