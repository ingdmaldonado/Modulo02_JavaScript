document.addEventListener('DOMContentLoaded', () => {
  const usuario = JSON.parse(localStorage.getItem('usuario'));
  const btnRegistro = document.getElementById('btnRegistro');
  const btnLogin = document.getElementById('btnLogin');
  const btnCerrar = document.getElementById('btnCerrarSesion');

  if (usuario) {
    // Ocultar botones de login/registro
    if (btnRegistro) btnRegistro.style.display = 'none';
    if (btnLogin) btnLogin.style.display = 'none';

    // Mostrar mensaje de bienvenida
    const bienvenida = document.createElement('h2');
    bienvenida.textContent = `Hola, ${usuario.nombre} ! Sos ${usuario.rol}`;
    document.body.appendChild(bienvenida);
  } else {
    // Si no hay usuario, ocultamos botón de cerrar sesión
    if (btnCerrar) btnCerrar.style.display = 'none';
  }

  // Evento para cerrar sesión
  if (btnCerrar) {
    btnCerrar.addEventListener('click', () => {
      localStorage.removeItem('usuario'); // eliminamos usuario logueado
      window.location.href = '../inicio.html'; // redirigimos al login
    });
  }
});