const formRegistro = document.getElementById('formularioRegistro');
const resultadoRegistro = document.getElementById('resultadoRegistro');
const nombreCompleto = document.getElementById('nombreCompleto').value;
const gmail = document.getElementById('gmail').value;
const contraseña = document.getElementById('contraseña').value;

formRegistro.addEventListener('submit', async (e) => {
e.preventDefault();


  const gmail = document.getElementById('gmail').value;
  const contraseña = document.getElementById('contraseña').value;
    const nombreCompleto = document.getElementById('nombreCompleto').value;
  try {
    const response = await fetch('http://localhost:3000/enviar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ nombre: nombreCompleto, gmail, contraseña })
    });

    const data = await response.json();
    resultadoRegistro.textContent = JSON.stringify(data, null, 2);
    if (!data.error) {
      window.location.href = '../Login/login.html';
    } else {
      alert(data.error);
    }

  } catch (error) {
    resultadoRegistro.textContent = error;
  }
});
