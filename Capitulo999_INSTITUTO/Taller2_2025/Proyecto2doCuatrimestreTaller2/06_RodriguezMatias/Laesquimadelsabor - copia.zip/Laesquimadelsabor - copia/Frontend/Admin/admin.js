//para que no puedan entrar a la pag admin desde el url si lo saben solo tnees que estar logiado como admin 
//modificar aca es el por que se puede entrar siendo cliente u otro rol
/*
document.addEventListener("DOMContentLoaded", () => {
  const usuario = JSON.parse(localStorage.getItem("usuario"));
  
  // Si no hay usuario logueado o no es admin, lo redirigimos
  if (!usuario || usuario.rol_nombre.toLowerCase() !== 1) {
    alert("No tenés permiso para acceder a esta página");
    window.location.href = "/inicio.html"; // o donde quieras redirigir
    return; // corta la ejecución
  }

  // Si es admin, cargamos la tabla
  cargarUsuarios();
});
*/
 const btnIrInicio = document.getElementById('btnIrInicio');
    btnIrInicio.addEventListener('click', () => {
      window.location.href = '../inicio.html'; // Ajusta la ruta según tu estructura
    });
document.addEventListener("DOMContentLoaded", cargarUsuarios);


let rolesDisponibles = [];
//carga los roles pra la tabla dinamica
async function cargarRoles() {
  try {
    const resRoles = await fetch("http://localhost:3000/roles");
    rolesDisponibles = await resRoles.json();
  } catch (error) {
    console.error("Error cargando roles:", error);
  }
}
//carga los usuarios a una tabla dinamica 
async function cargarUsuarios() {
 await cargarRoles(); 
  try {
    const res = await fetch("http://localhost:3000/Admin"); // GET usuarios
    const usuarios = await res.json();


    
    const tbody = document.getElementById("tablaUsuarios");
    tbody.innerHTML = "";

    usuarios.forEach(u => {
  // Generamos las opciones del select para este usuario
  let opcionesRol = "";
  rolesDisponibles.forEach(r => {
    opcionesRol += `<option value="${r.rol_id}" ${u.rol_id === r.rol_id ? "selected" : ""}>${r.nombre}</option>`;
  });

  // Ahora sí creamos la fila
  const fila = document.createElement("tr");

      fila.innerHTML = `
  <td>${u.usuarioid}</td>
  <td><input type="text" value="${u.usuarionombre}" id="nombre-${u.usuarioid}"></td>
  <td><input type="text" value="${u.usuariogmail}" id="gmail-${u.usuarioid}"></td>
  <td><input type="text" value="${u.usuariocontraseña}" id="contraseña-${u.usuarioid}"></td>
  <td>
    <select id="rol-${u.usuarioid}">
      ${opcionesRol} 
    </select>
  </td>
  <td>
    <button onclick="actualizarUsuario(${u.usuarioid})">Guardar</button>
    <button onclick="eliminarUsuario(${u.usuarioid})">Eliminar</button>
  </td>
`;

      tbody.appendChild(fila);
    });
  } catch (error) {
    console.error("Error cargando usuarios:", error);
  }
};

// Actualizar usuario
async function actualizarUsuario(id) {
  const nombre = document.getElementById(`nombre-${id}`).value;
  const gmail = document.getElementById(`gmail-${id}`).value;
  const contraseña = document.getElementById(`contraseña-${id}`).value;
  const rol = document.getElementById(`rol-${id}`).value;

  try {
    const res = await fetch(`http://localhost:3000/Admin/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ nombre, gmail, contraseña, rol })
    });

    const usuarioLogueado = JSON.parse(localStorage.getItem("usuario"));

// Si el usuario que se actualizó es el mismo que el logueado
if (usuarioLogueado && usuarioLogueado.id === id) {
  // Actualizamos el rol en localStorage para que se refleje en inicio.html
  usuarioLogueado.rol = rolesDisponibles.find(r => r.rol_id == rol).nombre;
  localStorage.setItem("usuario", JSON.stringify(usuarioLogueado));
}

    const data = await res.json();
    alert(data.mensaje || "Error al actualizar");
    cargarUsuarios();
  } catch (error) {
    console.error("Error actualizando usuario:", error);
  }
}

// Eliminar usuario
async function eliminarUsuario(id) {
  if (!confirm("¿Seguro que querés eliminar este usuario?")) return;

  try {
    const res = await fetch(`http://localhost:3000/Admin/${id}`, {
      method: "DELETE"
    });

    const data = await res.json();
    alert(data.mensaje || "Error al eliminar");
    cargarUsuarios();
  } catch (error) {
    console.error("Error eliminando usuario:", error);
  }
} 