// instanciaUnica.js
// 🧠 Control para evitar que la misma pantalla esté abierta en múltiples pestañas

export function inicializarInstanciaUnica(nombrePantalla) {
  const instanciaId = crypto.randomUUID(); // 🔐 Generamos un ID único para esta instancia
  const claveStorage = `instanciaActiva_${nombrePantalla}`; // 🔑 Clave única por pantalla

  // 💾 Guardamos nuestra instancia como activa
  localStorage.setItem(claveStorage, instanciaId);

  // 🎯 Detectamos si otra pestaña modifica esa instancia
  window.addEventListener("storage", (e) => {
    if (e.key === claveStorage && e.newValue !== instanciaId) {
      // ⚠️ Otra pestaña tomó el control
      document.body.innerHTML = `
        <div style="text-align:center; padding:2rem;">
          <h1>⚠️ Pantalla Duplicada</h1>
          <p>Otra pestaña está usando esta pantalla actualmente.</p>
        </div>
      `;
      window.stop?.();
    }
  });

  // 🧹 Eliminamos la clave cuando cerramos la pestaña
  window.addEventListener("beforeunload", () => {
    if (localStorage.getItem(claveStorage) === instanciaId) {
      localStorage.removeItem(claveStorage);
    }
  });
}
