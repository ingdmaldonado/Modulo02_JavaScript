// pantalla2.js
// ✅ Lógica de la pantalla2 con estado persistente y control de duplicidad modularizado

import { inicializarInstanciaUnica } from './instanciaUnica.js';
import { guardarEstadoPantalla, leerEstadoPantalla } from './persistenciaEstado.js';

// 📁 Detectamos dinámicamente el nombre del archivo actual para usarlo como clave de instancia y estado
const nombreArchivoActual = window.location.pathname.split("/").pop();

// 🧩 Inicializamos el control para evitar pantallas duplicadas
// 📌 Esta función registra el ID único de la instancia actual
// y además agrega un listener global al evento 'storage' para detectar si otra pestaña intenta tomar el control de esta pantalla
inicializarInstanciaUnica(nombreArchivoActual);

window.addEventListener("load", () => {
  // 🔗 Referencias a los elementos del DOM
  const selectPais = document.getElementById("idPais");
  const btnFinalizar = document.getElementById("idBtnFinalizar");

  // 🧠 Recuperamos el estado guardado para esta pantalla
  const estadoActual = leerEstadoPantalla(nombreArchivoActual);

  // 🖋️ Rellenamos el campo con el valor guardado (si existía)
  selectPais.value = estadoActual.pais || "";

  // 🎧 Guardamos automáticamente al cambiar la selección
  selectPais.addEventListener("change", () => {
    estadoActual.pais = selectPais.value;
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
  });

  // 📤 Finalizamos y mostramos todo el estado en un alert
  btnFinalizar.addEventListener("click", () => {
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
    alert("✅ Estado completo:\n" + localStorage.getItem("estadoAplicacion"));
  });
});

// 🔄 Evento pageshow: detecta si volvemos con la flecha (historial)
window.addEventListener("pageshow", (event) => {
  if (event.persisted) {
    console.log("🕘 Página restaurada desde el historial (bfcache). Usuario volvió con la flecha.");
  } else {
    console.log("✔ Página cargada normalmente (como lo haría el evento load).");
  }
});
