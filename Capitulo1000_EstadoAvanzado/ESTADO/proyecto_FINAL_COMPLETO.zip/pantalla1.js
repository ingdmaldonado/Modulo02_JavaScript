// pantalla1.js
// ✅ Lógica de la pantalla1 con estado persistente y control de duplicidad modularizado

import { inicializarInstanciaUnica } from './instanciaUnica.js';
import { guardarEstadoPantalla, leerEstadoPantalla } from './persistenciaEstado.js';

// 📁 Detectamos dinámicamente el nombre del archivo actual para usarlo como clave de instancia y estado
const nombreArchivoActual = window.location.pathname.split("/").pop();

// 🧩 Inicializamos el control para evitar pantallas duplicadas
// 📌 Esta función registra el ID único de la instancia actual
// y además agrega un listener global al evento 'storage' para detectar si otra pestaña intenta tomar el control de esta pantalla
inicializarInstanciaUnica(nombreArchivoActual);

window.addEventListener("load", () => {
  // 🔗 Referencias a los elementos del DOM
  const inputFirstName = document.getElementById("idFirstName");
  const inputLastName = document.getElementById("idLastName");
  const inputEmail = document.getElementById("idEmail");
  const btnAceptar = document.getElementById("idBtnAceptar");

  // 🧠 Recuperamos el estado guardado para esta pantalla
  const estadoActual = leerEstadoPantalla(nombreArchivoActual);

  // 🖋️ Rellenamos los campos con los valores guardados (si los hubiera)
  inputFirstName.value = estadoActual.FirstName || "";
  inputLastName.value = estadoActual.LastName || "";
  inputEmail.value = estadoActual.Email || "";

  // 🎧 Guardamos automáticamente el estado al modificar los campos
  inputFirstName.addEventListener("input", () => {
    estadoActual.FirstName = inputFirstName.value;
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
  });

  inputLastName.addEventListener("input", () => {
    estadoActual.LastName = inputLastName.value;
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
  });

  inputEmail.addEventListener("input", () => {
    estadoActual.Email = inputEmail.value;
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
  });

  // 📤 Guardamos y redirigimos a pantalla2 cuando se hace clic en Aceptar
  btnAceptar.addEventListener("click", () => {
    guardarEstadoPantalla(nombreArchivoActual, estadoActual);
    window.location.href = "pantalla2.html";
  });
});

// 🔄 Evento pageshow: detecta si volvemos con la flecha (historial)
window.addEventListener("pageshow", (event) => {
  /**
   * pageshow se dispara SIEMPRE que la página se muestra:
   *  - Primera carga ✅
   *  - Recarga (F5) ✅
   *  - Volver con flecha "atrás" del navegador ✅
   *
   * En cambio, load NO siempre se dispara:
   *  - Sí en carga y F5 ✅
   *  - ❌ No se dispara si volvés con la flecha (bfcache)
   *
   * event.persisted === true indica que la página fue restaurada desde el historial
   */
  if (event.persisted) {
    console.log("🕘 Página restaurada desde el historial (bfcache). Usuario volvió con la flecha.");
  } else {
    console.log("✔ Página cargada normalmente (como lo haría el evento load).");
  }
});
