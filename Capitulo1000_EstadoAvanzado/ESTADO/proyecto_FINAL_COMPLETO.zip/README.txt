PROYECTO: APLICACIÓN CON DOS PANTALLAS Y ESTADO PERSISTENTE MODULARIZADO

Este proyecto contiene:

✅ Dos pantallas funcionales (pantalla1 y pantalla2)
✅ Control de duplicidad por pantalla usando localStorage + UUID
✅ Gestión del estado como un vector de pantallas en persistenciaEstado.js
✅ Manejo de eventos 'load' y 'pageshow' para cubrir todas las formas de navegación
✅ Comentarios línea por línea para fines didácticos
✅ Código listo para escalar y extender con nuevas pantallas

Estructura:
- pantalla1.js / pantalla2.js: lógica modular, persistente y protegida contra duplicados
- instanciaUnica.js: controla que una misma pantalla no se abra dos veces
- persistenciaEstado.js: guarda y recupera el estado de forma estructurada
- README.txt: este archivo con explicaciones claras

Uso:
1. Abrir pantalla1.html desde servidor local
2. Completar datos, navegar a pantalla2
3. Ver persistencia funcionando incluso al volver con flecha atrás

¡Ideal para clases y proyectos reales!
