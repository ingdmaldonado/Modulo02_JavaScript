// persistenciaEstado.js
// 📦 Módulo encargado de gestionar el estado persistente de la aplicación por pantalla.
// Se guarda todo en localStorage bajo la clave "estadoAplicacion" como un VECTOR de objetos.

const CLAVE_ESTADO = "estadoAplicacion"; // 🔑 Nombre de la clave donde se almacena el estado completo

// 🧾 Función interna que lee todo el vector de estado desde localStorage
function leerTodoElEstado() {
  const raw = localStorage.getItem(CLAVE_ESTADO);
  let estado = [];
  try {
    const data = JSON.parse(raw);
    if (Array.isArray(data)) {
      estado = data;
    }
  } catch (e) {
    console.warn("⚠️ Error al parsear estadoAplicacion:", e);
  }
  return estado;
}

// 📥 Devuelve el estado específico de una pantalla según su idPantalla
export function leerEstadoPantalla(idPantalla) {
  const estado = leerTodoElEstado();
  const bloque = estado.find(p => p.idPantalla === idPantalla);
  return bloque ? bloque.estado : {};
}

// 📤 Guarda el estado de una pantalla. Si ya existe, lo reemplaza.
export function guardarEstadoPantalla(idPantalla, nuevoEstado) {
  const estado = leerTodoElEstado().filter(p => p.idPantalla !== idPantalla);
  estado.push({ idPantalla, estado: nuevoEstado });
  localStorage.setItem(CLAVE_ESTADO, JSON.stringify(estado));
}
