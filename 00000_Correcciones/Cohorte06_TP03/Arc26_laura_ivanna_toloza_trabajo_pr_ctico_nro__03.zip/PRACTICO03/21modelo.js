
export const fnNotas = (nota)=>{
    if (nota >= 0 && nota <= 4) return `Desaprobado`;
    if (nota > 4 && nota <= 7) return `Aprobado`;
    if (nota > 7 && nota <= 9) return `Muy Bueno`;
    if (nota === 10) return `Excelente`;

    return `Nota Invalida`;
};