export const fnPromedioDeTres= (nota1,nota2,nota3)=>{
    
    return (nota1 + nota2 + nota3)/3;
};