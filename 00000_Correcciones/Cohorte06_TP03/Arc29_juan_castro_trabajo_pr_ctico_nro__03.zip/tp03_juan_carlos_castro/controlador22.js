/*

Ejercicio Nro. 22: 

El Gobierno Nacional desea aplicar un impuesto (Sobre Tasa) a las bebidas en función de la siguiente 
clasificación y tipo. 
1 – Bebidas Agua en envases plásticos = 5 ‰ (cinco por mil) 
2 – Bebidas Agua en envases retornables = 1 ‰ (uno por mil) 
3 – Bebidas Gaseosas Azucaradas en envases plásticos = 7 ‰ (siete por mil) 
4 – Bebidas Gaseosas Azucaradas en envases retornables = 2 ‰ (dos por mil) 
5 – Bebidas Energéticas = 15 ‰ (quince por mil) 
6 – Cualquier otra bebida no clasificada = 1 ‰ (uno por mil). 
 La función debe recibir el Importe Base de la Bebida, debe calcular y retornar la sobre Tasa, la 
recaudación de ese impuesto tendrá destino a la protección del medio ambiente. 

Nota: Debe devolver un número

*/

import { fnGuardar } from "./modelo22.js";
import { fnRecuperar } from "./modelo22.js";
import { fnTotalImporte } from "./modelo22.js";

window.onload = () => {

    const estadoAplicacion = {
        importe: 0,
        tipo: 0
    };

    const idSelectorBebida = document.querySelector("#idSelectorBebida");
    const idImporte = document.querySelector("#idImporte");
    const idCalcular = document.querySelector("#idCalcular");
    const idResultado = document.querySelector("#idResultado");

    fnRecuperar();

    idImporte.oninput = () => {
        estadoAplicacion.importe = Number(idImporte.value);
        fnGuardar(estadoAplicacion);
    };

    idSelectorBebida.oninput = () => {
        estadoAplicacion.tipo = Number(idSelectorBebida.value);
        fnGuardar(estadoAplicacion);
    };

    idBtnCalcular.onclick = () => {
        let resultado = fnTotalImporte(estadoAplicacion.importe, estadoAplicacion.tipo);
        idResultado.textContent = `El importe total es ${resultado}`;
    };

};