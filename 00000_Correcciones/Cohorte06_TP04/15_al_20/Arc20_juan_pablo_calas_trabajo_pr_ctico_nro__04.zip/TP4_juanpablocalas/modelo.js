/*
    VECTORES
*/

export const cohorte01 = [
{ dni: "12345678", nombre: "Juan", apellido: "Pérez", nota_final: 8 },
{ dni: "23456789", nombre: "Ana", apellido: "Gómez", nota_final: 6 },
{ dni: "34567890", nombre: "Carlos", apellido: "López", nota_final: 5 },
{ dni: "45678901", nombre: "María", apellido: "Martínez", nota_final: 7 }
];
export const cohorte02 = [
{ dni: "56789012", nombre: "Sofía", apellido: "Ramírez", nota_final: 9 },
{ dni: "67890123", nombre: "Luis", apellido: "Fernández", nota_final: 4 },
{ dni: "78901234", nombre: "Elena", apellido: "Torres", nota_final: 5 }
];
export const cohorte03 = [
{ dni: "89012345", nombre: "Pedro", apellido: "Álvarez", nota_final: 10 },
{ dni: "90123456", nombre: "Clara", apellido: "Méndez", nota_final: 3 },
{ dni: "12345679", nombre: "Jorge", apellido: "Salinas", nota_final: 6 },
{ dni: "23456780", nombre: "Natalia", apellido: "Cruz", nota_final: 2 },
{ dni: "34567891", nombre: "Sergio", apellido: "Paredes", nota_final: 8 }
];
export const cohorte04 = [
{ dni: "45678902", nombre: "Lucía", apellido: "Ortiz", nota_final: 7 },
{ dni: "56789013", nombre: "Miguel", apellido: "Vega", nota_final: 4 },
{ dni: "67890124", nombre: "Raquel", apellido: "Silva", nota_final: 9 },
{ dni: "78901235", nombre: "Hugo", apellido: "Moreno", nota_final: 5 },
{ dni: "89012346", nombre: "Natalia", apellido: "Quinteros", nota_final: 6 },
{ dni: "90123457", nombre: "Diego", apellido: "Arce", nota_final: 3 }
];

/*
    Funciones
*/

export const fnRetornaCorteSeleccionada = (IdCohorte)=>{
    let Cohorte = 0
    switch(IdCohorte)
    {
        case 1:
            {
//                fnMuestraAlumno(cohorte01,"ALUMNOS COHORTE01");
                Cohorte = cohorte01;
                break;
            }
        case 2:
            {
//                fnMuestraAlumno(cohorte02,"ALUMNOS COHORTE02");
                Cohorte = cohorte02;
                break;

            }
        case 3:
            {
//                fnMuestraAlumno(cohorte03,"ALUMNOS COHORTE03");
                Cohorte = cohorte03;
                break;

            }                        
        case 4:
            {
//                fnMuestraAlumno(cohorte04,"ALUMNOS COHORTE04");
                Cohorte = cohorte04;
                break;

            }            
    };

    return Cohorte;

};

export const fnMuestraAlumno = (cohorte,NombreCohorte)=>{
    console.log(NombreCohorte)
    cohorte.forEach(alumnos => {
        console.log(`Apellido: ${alumnos.apellido} - Nombre: ${alumnos.nombre}`);
    });
};

export const fnMuestraAlumnonNota = (cohorte,NombreCohorte)=>{
    console.log(NombreCohorte)
    cohorte.forEach(alumnos => {
        console.log(`Apellido: ${alumnos.apellido} - Nombre: ${alumnos.nombre} - NOTA: ${alumnos.nota_final}`);
    });
};

export const fnCuentaAprobados = (AlumnosCohortes)=>{
    let Aprobados = 0;
    AlumnosCohortes.forEach(AlumnosNotas=> {
        if(AlumnosNotas.nota_final > 5){
             Aprobados = Aprobados + 1;

        };
});
    return Aprobados
};


export const fnCuentaAprobadosOT = (AlumnosCohortes)=>{
    let AprobadosOT = 0;
    AlumnosCohortes.forEach(AlumnosNotas=> {
        AprobadosOT += AlumnosNotas.nota_final > 5 ? 1 : 0;
});
    return AprobadosOT
};


export const fnCuentaDesAprobados = (AlumnosCohortes)=>{
    let DesAprobados = 0;
    AlumnosCohortes.forEach(AlumnosNotas=> {
        if(AlumnosNotas.nota_final <= 5){
             DesAprobados = DesAprobados + 1;

        };
});
    return DesAprobados
};

export const fnCuentaDesAprobadosOT = (AlumnosCohortes)=>{
    let DesAprobadosOT = 0;
    AlumnosCohortes.forEach(AlumnosNotas=> {
        DesAprobadosOT += AlumnosNotas.nota_final <= 5 ? 1 : 0;
});
    return DesAprobadosOT
};