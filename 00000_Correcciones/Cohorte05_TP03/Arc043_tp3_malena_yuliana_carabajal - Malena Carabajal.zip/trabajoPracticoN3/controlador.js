import {determinarPrecioDeVenta} from "./modelo.js"

window.onload = () => 
    {
        console.log(`aplication is running`);
        //ejercicio 13//
        let precioFinal = determinarPrecioDeVenta(120000, 80);
        console.log(precioFinal);

        //ejercicio 14//
    }