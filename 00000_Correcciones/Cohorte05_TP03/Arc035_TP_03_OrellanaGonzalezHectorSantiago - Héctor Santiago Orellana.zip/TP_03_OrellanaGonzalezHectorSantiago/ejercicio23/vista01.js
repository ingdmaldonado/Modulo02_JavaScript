import { fncontidadS} from "./modulo01.js";


/* paso dos invocación de la función*/

{
console.log(`APLICACIÓN EXTRAER "S"`);/* comprovación de que el programa este funcionando*/

 let resultado= fncontidadS(`hola soy santi`); /* definición y creación de la variable, invocación de la Arrow Fuction, ingreso de los valores en el parametro definido*/
 let cantidaDeS=`LA CANTIDAD DE "S" INGRESADAS ES: `/* definición y creación de la variable que mostrara los valores verdaderos ingresados en el programa*/

 console.log(cantidaDeS, resultado); /*visualización en pantalla de los resultados optenidos*/
 
}