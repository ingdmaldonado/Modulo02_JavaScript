
/*Ejercicio Nro. 14:
Realizar una arrow function que reciba como parámetro las 3 notas que obtuvo un alumno en los distintos trabajos prácticos de una materia y que a partir de esas notas obtenga el promedio de las mismas
Nota: Debe devolver un número*/

/* primer paso declaracion de la función*/


export const fnnotasObtenidas= (nota1,nota2,nota3)=> 
    
    
    {
        

        return (nota1+ nota2+nota3)/3; /* en esta linea retorna el volar de la funcion*/
    };


