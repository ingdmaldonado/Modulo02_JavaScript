
    import { fnnotasObtenidas } from "./controlador.js";
    /*area del programa principal invocación de la variable*/
{
    console.log(`3 NOTAS DE UN ALUMNO EN LOS DISTINTOS TRABAJOS PRÁCTICOS`);

    let resultado1= fnnotasObtenidas(10,10,9)

    console.log(`EL RESULTADO PROMEDIO DE SUS NOTAS ES:`,resultado1);


}