import { fncontidadConsonantes} from "./modulo01.js";


/* paso dos invocación de la función*/

{
console.log(`APLICACIÓN CANTIDAD DE CONSONANTES`);/* comprovación de que el programa este funcionando*/

 let resultado= fncontidadConsonantes(`hola me llamo santiago `); 
 let consonates=`LA CANTIDAD DE CONSONANTES ES: `

 console.log(consonates,resultado);
 
}