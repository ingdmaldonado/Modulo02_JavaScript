import { fncalcularNotaPromedio } from "./contrador.js";
/* área del programa principla invocación de la función y visualización de los resultados obtenidos*/


{
/*probando y visualizando los resultados del programa*/

    console.log(` LAS NOTAS OBTENIDAS FUERON`)
    let resultado= fncalcularNotaPromedio (10);
    let resultado1= fncalcularNotaPromedio (5);
    let resultado2= fncalcularNotaPromedio (1);
    let resultado3= fncalcularNotaPromedio (9);
    let resultado4= fncalcularNotaPromedio (11);
    
console.log(`Nota Alumno1:${resultado} Nota Alumno2:${resultado1} Nota Alumno:${resultado2} Nota Alumno3:${resultado3} valor ingresado:${resultado4} `);


}

