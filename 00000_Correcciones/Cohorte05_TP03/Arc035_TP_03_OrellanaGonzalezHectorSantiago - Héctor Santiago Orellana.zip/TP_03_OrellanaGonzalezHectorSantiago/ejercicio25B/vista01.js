import { fncodenaDeCaracteres} from "./modulo01.js"; /* importación de la Arrow Fuction*/


/* paso dos invocación de la función*/

{
console.log(`EL CARACTER DE LA CADENA INGRESADA ES:`); 

 let resultado= fncodenaDeCaracteres(`0`); /*creación y definición de la variable que contiene a la arrow fuction, ingreso de de valor el parametro establecido*/
 

 console.log(resultado); /* visualización de resultados*/
 
}