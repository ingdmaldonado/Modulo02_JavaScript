import { fncantidadEspacio} from "./modulo01.js";


/* paso dos invocación de la función*/

{
console.log(`APLICACIÓN CONTAR ESPACIOS EN BLANCOS PERMITIDOS`);/* comprovación de que el programa este funcionando*/

 let resultado= fncantidadEspacio(`h  o l a a`); /* definición y creación de la variable, invocación de la Arrow Fuction, ingreso de los valores en el parametro definido*/

 console.log(`LA CADENA LLEGO AL LIMITE DE ESPACIOS AUTORIZADOS`, resultado); /*visualización en pantalla de los resultados optenidos*/
 
}