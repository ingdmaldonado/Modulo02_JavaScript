import { fnretornarPrecioDeVenta } from "./controlador.js";
{ 

   console.log(`ACORDE A SU IMPORTE DE COMPRA Y EL MARGEN DE GANANCIA`);

   let resultado= fnretornarPrecioDeVenta(10000,50);

   console.log(`SU PRECIO DE VENTA FINAL ES:`,resultado);
    

  

};
