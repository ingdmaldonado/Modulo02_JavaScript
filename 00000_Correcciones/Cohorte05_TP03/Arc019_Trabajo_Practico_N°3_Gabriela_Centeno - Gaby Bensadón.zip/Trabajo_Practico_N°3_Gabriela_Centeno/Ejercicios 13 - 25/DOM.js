/** 
    PRACTICA DOM
*/
window.onload = () =>{

    /**
     Ejercicio 13
     */

    
     


}; 