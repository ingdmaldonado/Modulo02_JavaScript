import {calculoPrecioVenta,promedioNotas,resultadoExamen,calculoSobreTasa,calcularImporteAgua,calculoTasaSubsuelo,calculoTasaFiscalizacion,dosisDeInsulina,vocales,consonantes,cantidadDeS,contadorDeEspacios,cadenaSinNumeros} from "./modelo.js"

{
    // EJERCICIO 13

    console.log(calculoPrecioVenta(1000,25))


    // EJERCICIO 14

    console.log(promedioNotas(10,9,7))


    // EJERCICIO 15

    console.log(resultadoExamen(10))


    // EJERCICIO 16

    console.log(calculoSobreTasa(3,10000))


    // EJERCICIO 17

    console.log(calcularImporteAgua(30))


    // EJERCICIO 18

    console.log(calculoTasaSubsuelo(10000))


    // EJERCICIO 19

    console.log(calculoTasaFiscalizacion(10000))


    // EJERCICIO 20

    console.log(dosisDeInsulina(175,150,1))


    // EJERCICIO 21

    console.log(vocales("texto de prueba con vocales")) // 10 vocales


    // EJERCICIO 22

    console.log(consonantes("texto de prueba con consonantes")) // 16 consonantes 


    // EJERCICIO 23

    console.log(cantidadDeS("casas"))


    // EJERCICIO 24

    console.log(contadorDeEspacios("texto con mas de un espacio"))


    // EJERCICIO 25

    console.log(cadenaSinNumeros("cadena de texto con 1 número"))

}