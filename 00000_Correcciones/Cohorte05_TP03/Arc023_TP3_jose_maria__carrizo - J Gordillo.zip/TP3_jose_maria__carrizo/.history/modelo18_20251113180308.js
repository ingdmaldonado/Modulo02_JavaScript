
export const calcularTasaSubsuelo = (importe) => {
    return importe * 0.03;
};
