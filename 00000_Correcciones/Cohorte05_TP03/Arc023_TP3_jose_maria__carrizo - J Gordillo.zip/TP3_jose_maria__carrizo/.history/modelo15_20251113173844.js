
export const calcularCuadradoYRaiz = (n) => {
    return {
        cuadrado: n * n,
        raiz: Math.sqrt(n)
    };
};
