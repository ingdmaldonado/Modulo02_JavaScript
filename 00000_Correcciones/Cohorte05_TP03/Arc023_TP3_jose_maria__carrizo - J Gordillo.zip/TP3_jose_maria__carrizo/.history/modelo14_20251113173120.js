
export const calcularPromedioNotas = (n1, n2, n3) => {
  const promedio = (n1 + n2 + n3) / 3;
  return promedio;
};
