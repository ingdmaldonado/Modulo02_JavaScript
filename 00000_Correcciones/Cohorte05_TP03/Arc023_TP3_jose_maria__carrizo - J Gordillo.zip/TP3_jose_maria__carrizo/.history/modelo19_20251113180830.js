export const calcularTasaENRE = (importe) => {
    return importe * 0.012;
};
