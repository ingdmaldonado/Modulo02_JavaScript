import { notaAlumno } from "./modelo.js";

window.onload = () =>{

    let nota = notaAlumno(10.1);

    console.log(nota);

    
     
};