import { precioVenta } from "./modelo.js";

window.onload = () => {

    console.log(`La pagina esta cargada`);
   

    let resultado1 = precioVenta(700,100);
    console.log(resultado1);
}          