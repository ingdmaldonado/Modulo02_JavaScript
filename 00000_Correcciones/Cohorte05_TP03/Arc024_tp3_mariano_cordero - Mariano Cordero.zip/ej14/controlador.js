import {promedioTresNotas} from "./modelo.js"

window.onload = () => {

    let resultado = promedioTresNotas(9,10,7);
    console.log(resultado);
};