import { extraerS } from "./modelo.js";

window.onload = () => {

    let palabra1 = "Mariano";
    let palabra2 = "Samuel";
    let palabra3 = "Samsung";

    extraerS(palabra1);
    extraerS(palabra2);
    extraerS(palabra3);

}
