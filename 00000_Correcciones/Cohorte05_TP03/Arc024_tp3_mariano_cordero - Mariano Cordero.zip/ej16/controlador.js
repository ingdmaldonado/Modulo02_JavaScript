import {calcularSobreTasa} from "./modelo.js";

window.onload = () => {

    let resultado = calcularSobreTasa(1,5000000);
   console.log(resultado);
};