import { vocalesMayusculasMinusculas } from "./modelo.js";

window.onload = () => {

        let texto1 = `Hola profe, muchas gracias por sus enseñanzas`;
        let texto2 = `Saludos a todos`;

        
       vocalesMayusculasMinusculas(texto1); //Texto 1

        vocalesMayusculasMinusculas(texto2); //Texto 2
    
}; 