import { detectorDeNumeros } from "./modelo.js";

window.onload = () =>{

    let texto1 = " Soy mariano y tengo 27 años";
    let texto2 = " Soy alumno de informatica";
    
    detectorDeNumeros(texto1);
    detectorDeNumeros(texto2);
};