 import { consonantesMayusculasMinusculas } from "./modelo.js";

 window.onload = () => {
 
         let texto1 = `Hola profe, muchas gracias por sus enseñanzas`;
         let texto2 = `Saludos a todos`;
 
         
        consonantesMayusculasMinusculas(texto1); //Texto 1
 
        consonantesMayusculasMinusculas(texto2); //Texto 2
     
 }; 