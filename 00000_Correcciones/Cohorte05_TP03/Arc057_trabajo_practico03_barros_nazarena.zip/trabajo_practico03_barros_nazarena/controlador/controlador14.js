/*Ejercicio Nro. 14:
Realizar una arrow function que reciba como parámetro las 3 notas que obtuvo un alumno en los
distintos trabajos prácticos de una materia y que a partir de esas notas obtenga el promedio de las mismas
Nota: Debe devolver un número */

// Notas de ejemplo simulando valores ingresados por un alumno
const n1 = 7;
const n2 = 8;
const n3 = 6;

const promedioFinal = promedioNotas(n1, n2, n3);

console.log("Notas:", n1, n2, n3);
console.log("Promedio:", promedioFinal)