/*Ejercicio Nro. 22:
Realizar una arrow function que reciba como parámetro una cadena de texto y devuelva cuántas
consonantes contiene (mayúsculas o minúsculas). Es decir consideramos consonante a todo carácter que NO
SEA VOCAL.
Debe recorrer la cadena con un ciclo for, analizar cada carácter y determinar si es una letra que no sea vocal.
No debe utilizar métodos de strings como replace(), split() o expresiones regulares.
Nota: Debe devolver un número. */

console.log("Consonantes en 'Hola Mundo':", contarConsonantes("Hola Mundo"));
console.log("Consonantes en 'Estudiante':", contarConsonantes("Estudiante"));
console.log("Consonantes en 'xyz123':", contarConsonantes("xyz123"));