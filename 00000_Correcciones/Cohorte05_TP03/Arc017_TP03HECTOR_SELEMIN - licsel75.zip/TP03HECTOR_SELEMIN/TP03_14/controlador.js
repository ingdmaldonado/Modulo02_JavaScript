
import {promedioDeTres} from "./modulo.js";



window.onload = ()=>{

  

    console.log(`la pagina esta cargada`);  


    
    let resulatado = promedioDeTres(10,10,7);
    console.log(resulatado);



};





