
import {calcularPrecioVenta} from "./modulo.js";



window.onload = ()=>{

  

    console.log(`la pagina esta cargada`);  


    
    let resulatado = calcularPrecioVenta(590,100);
    console.log( resulatado   );



};





