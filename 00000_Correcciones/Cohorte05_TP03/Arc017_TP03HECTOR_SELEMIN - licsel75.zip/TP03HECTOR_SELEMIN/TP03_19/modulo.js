


export const determinarTasaDeFiscalizacion = (importeBase)=>{

   

    let tasaFiscalizacion = 0;
    tasaFiscalizacion=(importeBase*1.2)/100;



    return tasaFiscalizacion;

};






