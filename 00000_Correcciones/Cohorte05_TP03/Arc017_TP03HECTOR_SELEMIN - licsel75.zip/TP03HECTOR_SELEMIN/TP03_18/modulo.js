


export const determinarTasaSubSuelo = (importeBase)=>{

   

    let tasaSubSuelo = 0;
    tasaSubSuelo=(importeBase*3.2)/100;



    return tasaSubSuelo;

};






