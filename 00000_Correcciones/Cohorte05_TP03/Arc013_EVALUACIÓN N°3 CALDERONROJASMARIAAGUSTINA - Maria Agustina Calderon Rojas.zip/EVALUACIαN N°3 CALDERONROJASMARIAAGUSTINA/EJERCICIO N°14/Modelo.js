// =============================
// MODELO: Contiene las funciones lógicas
// =============================

// Arrow function que calcula el promedio de tres notas
export const calcularPromedio = (nota1, nota2, nota3) => {
    return (nota1 + nota2 + nota3) / 3;
};