/* este archvo sera usado para exportar todos los resultados de las operaciones  */

