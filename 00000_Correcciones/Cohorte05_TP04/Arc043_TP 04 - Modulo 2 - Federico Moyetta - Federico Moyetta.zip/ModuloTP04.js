export const fnRecorreCohortes = (cohorteXX) => {

    cohorteXX.forEach(({ apellido, nombre, nota_final }) => {

        console.log(`Apellido: ${apellido} - Nombres: ${nombre} - Nota: ${nota_final}`);
    });



};



