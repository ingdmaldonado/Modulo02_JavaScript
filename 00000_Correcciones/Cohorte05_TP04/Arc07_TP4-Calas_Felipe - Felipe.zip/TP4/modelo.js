


export const fnEjercicio1 = (cohorte) => 
    {

        let resultado = cohorte.forEach(alumno => {console.log(alumno.nombre,alumno.apellido)});
        return resultado
        
    } 