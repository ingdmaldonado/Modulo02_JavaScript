/*
Ejercicio Nro. 15: 
Realizar un programa en JavaScript que permita ingresar las notas de los trabajos finales de los alumnos de 
la diplomatura en “Desarrollo Web Full Stack con JavaScript” para ello se establecen las siguientes condiciones. - 
No está establecido la cantidad de trabajos finales que se evaluarán - - - 
Este será el cuadro con el que se analizará y asignará la clasificación de los mismos. 
o Si la nota >= 0 y <= 4 serán trabajos desaprobados 
o Si la nota > 4 y <= 7 serán trabajos aprobados 
o Si la nota > 7 y <10 serán trabajos muy buenos 
o Si la nota = 10 serán trabajos excelentes 
Contemplar que el operador podría ingresar notas incorrectas, es decir podría poner una nota menor 
a cero o mayor a 10 con lo que sería claramente un error. Contemplar la cantidad de veces que se 
equivoca. 
Siempre preguntar si desea continuar cargando notas. 
Consideraciones: para realizar el ejercicio debe utilizar solamente código JavaScript, sin interacción con el 
DOM y cargar los datos de entrada por medio de prompt. 
*/

{
    let nota = 0;
    let desaprobados = 0;
    let aprobados = 0;
    let muyBuenos = 0;
    let excelentes = 0;
    let errores = 0;
    let continuar = `S`;

    while(continuar === `S`)
    {
        nota = Number(prompt(`Ingrese nota del alumno`));

        if((nota >= 0) && (nota <= 4))
        {
            console.log(`Trabajo desaprobado`);
            desaprobados = desaprobados + 1;
        }

        if((nota > 4) && (nota <= 7))
        {
            console.log(`Trabajo aprobado`);
            aprobados = aprobados + 1;
        }

        if((nota > 7) && (nota < 10))
        {
            console.log(`Trabajo muy bueno`);
            muyBuenos = muyBuenos + 1;
        }

        if(nota == 10)
        {
            console.log(`Trabajo excelente`);
            excelentes = excelentes + 1;
        }

        if((nota < 0) || (nota > 10))
        {
            console.log(`Nota incorrecta`);
            errores = errores + 1;
        }

        continuar = prompt(`Desea continuar ?. (S/N)`);
    }

    console.log(`La cantidad de desaprobados es: ${desaprobados}`);
    console.log(`La cantidad de aprobados es: ${aprobados}`);
    console.log(`La cantidad de muy buenos es: ${muyBuenos}`);
    console.log(`La cantidad de excelentes es: ${excelentes}`);
    console.log(`Cantidad de errores al corregir: ${errores}`);
}