/*

  La regla que les podés dejar grabada a los alumnos:

  modelo.js     → habla con el servidor
  vista.js      → habla con el DOM
  controlador.js → habla con el modelo y con la vista, nunca directamente con el servidor ni con el DOM

*/
/*
el objetivo es conectarme ak end point de una api 
conjunto de los enpoint que pone una emplera 
ya sea empresa propia o externas */




    /*
  CÓDIGOS DE ESTADO HTTP
  ======================

  request.status     → el número  — 200, 404, 500, etc
  request.statusText → el texto   — "OK", "Not Found", "Internal Server Error"
  request.ok         → booleano   — true si está entre 200 y 299, false si no

  request.ok === true  → status entre 200 y 299 → todo bien
  request.ok === false → status fuera de 200-299 → algo falló

  2xx — ÉXITO — request.ok === true
  ----------------------------------
  200 OK
      La solicitud fue exitosa.
      GET que devuelve datos, POST que procesa correctamente.

  201 Created
      El recurso fue creado exitosamente.
      Respuesta típica de un POST que crea un registro en la BD.

  204 No Content
      La solicitud fue exitosa pero no hay contenido que devolver.
      Respuesta típica de un DELETE exitoso.

  3xx — REDIRECCIONES — request.ok === false
  ------------------------------------------
  301 Moved Permanently
      El recurso se movió a otra URL de forma permanente.
      El servidor indica la nueva URL.

  302 Found
      El recurso se movió temporalmente a otra URL.

  304 Not Modified
      El recurso no cambió desde la última vez que se pidió.
      El navegador puede usar la versión en caché.

  4xx — ERRORES DEL CLIENTE — request.ok === false
  -------------------------------------------------
  400 Bad Request
      La solicitud está mal formada o tiene datos inválidos.
      Cuando mandás un JSON con campos incorrectos o faltantes.

  401 Unauthorized
      No estás autenticado.
      Cuando intentás acceder sin haber iniciado sesión.

  403 Forbidden
      Estás autenticado pero no tenés permisos.
      Un usuario común intentando acceder a una ruta de administrador.

  404 Not Found
      El recurso no existe en el servidor.
      URL mal escrita, id que no existe, recurso eliminado.

  405 Method Not Allowed
      El método HTTP no está permitido para esa ruta.
      Hacer un DELETE a una ruta que solo acepta GET.

  408 Request Timeout
      El servidor esperó demasiado y cerró la conexión.
      Conexión lenta o servidor ocupado.

  409 Conflict
      Conflicto con el estado actual del recurso.
      Intentar crear un usuario con un email que ya existe.

  422 Unprocessable Entity
      El servidor entiende la solicitud pero no puede procesarla.
      Validaciones fallidas — campo requerido vacío, formato inválido.

  429 Too Many Requests
      Demasiadas solicitudes en poco tiempo.
      El servidor aplicó rate limiting.

  5xx — ERRORES DEL SERVIDOR — request.ok === false
  --------------------------------------------------
  500 Internal Server Error
      Error genérico del servidor.
      Excepción no controlada en el BackEnd, bug en el código del servidor.

  501 Not Implemented
      El servidor no soporta la funcionalidad requerida.

  502 Bad Gateway
      El servidor actuó como proxy y recibió una respuesta inválida.
      El BackEnd está caído o no responde.

  503 Service Unavailable
      El servidor no está disponible temporalmente.
      Mantenimiento, sobrecarga, o el servidor se cayó.

  504 Gateway Timeout
      El servidor proxy no recibió respuesta a tiempo del servidor destino.
      El BackEnd tardó demasiado en responder.
*/
// CORREGIDO: Se agregó el .js al final de la ruta para evitar el Error 404


/* La regla que les podés dejar grabada a los alumnos:
  modelo.js     → habla con el servidor
  vista.js      → habla con el DOM
  controlador.js → habla con el modelo y con la vista, nunca directamente con el servidor ni con el DOM
*/

import { fnRecuperarUniversidades } from "./universidadmodelo.js";
import { fnUniversidadView,fnRender,fnUniversidadViews} from "./universidadvista.js"



window.onload = () => {
    const SelectPaises = document.querySelector("#idSelectPaises");
    const idBtnRecuperar = document.querySelector("#idBtnRecuperar");
    const idResultado = document.querySelector("#idResultado");
    const idTablaUniversidades = document.querySelector("#idTablaUniversidades");
 
    idBtnRecuperar.onclick = async () => {
        const paisElegido = Number(SelectPaises.value);
        
        console.log(`País elegido: ${paisElegido}`);

      

        const datos = await fnRecuperarUniversidades(paisElegido);
        console.log(datos); 

        // aca muestro la primera universidad
        console.log(datos[0]);

        const fila =  fnUniversidadView(datos[0]);

        console.log(fila);

        const filas = fnUniversidadViews(datos);

        console.log(filas);

        // ahora renderizo todas las filas en la tabla
        fnRender(filas, idTablaUniversidades);



    }
     
};